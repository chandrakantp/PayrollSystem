﻿using edueTree.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace edueTree.webservice
{
    /// <summary>
    /// Summary description for Getattendace
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Getattendace : System.Web.Services.WebService
    {

        #region Dbcontext
        private dbContainer _db = new dbContainer();
        #endregion

        #region GetAttendace
        /// <summary>
        /// This webserice is responsible for Fill Attendace using attendace machine
        /// </summary>
        /// <param name="mid"></param>
        /// <param name="idwEnrollNumber"></param>
        /// <param name="idwVerifyMode"></param>
        /// <param name="idwInOutMode"></param>
        /// <param name="idwYear"></param>
        /// <param name="idwMonth"></param>
        /// <param name="idwDay"></param>
        /// <param name="idwHour"></param>
        /// <param name="idwMinute"></param>
        /// <param name="idwSecond"></param>
        /// <param name="idwWorkcode"></param>
        /// <param name="firmId"></param>
        /// <returns></returns>
        [WebMethod]
        public string AddAttendanceusingmachindata(int mid, string idwEnrollNumber, int idwVerifyMode, int idwInOutMode, int idwYear, int idwMonth, int idwDay, int idwHour, int idwMinute, int idwSecond, int idwWorkcode, int firmId)
        {
            string C = "0";
            try
            {

            var dates = new DateTime(idwYear, idwMonth, idwDay, idwHour, idwMinute, idwSecond);
          //  int count = _db.AddattendanceifnotExit(idwEnrollNumber, idwInOutMode, idwVerifyMode, idwWorkcode, dates, firmId);
            // return count;

            var check = _db.AttendanceStaffs.Count(a =>
                        a.enrollNumber == idwEnrollNumber && a.inOutMode == idwInOutMode && a.verifyMode == idwVerifyMode &&
                        a.worCode == idwWorkcode && a.attendDate == dates && a.firmId == firmId && a.machineId==mid);
            if (check == 0)
            {

                var data = _db.MemberattendaceConfigs.FirstOrDefault(a => a.Machineid == mid && a.FingureId == Convert.ToInt32(idwEnrollNumber) && a.FirmId==firmId);
                if (data != null)
                {
                    var attend = new AttendanceStaff
                    {
                        enrollNumber = idwEnrollNumber,
                        inOutMode = idwInOutMode,
                        verifyMode = idwVerifyMode,
                        worCode = idwWorkcode,
                        attendDate = dates,
                        firmId = firmId,
                        StaffId = data.StaffId,
                        AttendMode = "Machine"
                     
                    };

                    _db.AttendanceStaffs.Add(attend);
                    _db.SaveChanges();
                    C = "1";
                }
                
                return C;
            }
            }
            catch (Exception)
            {
                return C; 
               
            }
            return C; 
        }
        #endregion

        #region Get Record if serialkey is exist

        /// <summary>
        /// If serial key Record is Exist in Database It will return List of Record
        /// </summary>
        /// <param name="serialkey"> serialkey </param>
        /// <returns>List </returns>
        /// 
        [WebMethod]
        public string GetSerialKeyisExistlist(string serialkey)
        {
            try
            {
                var machineconfigList = (_db.MachineConfigures.Where(a => a.SerialKey == serialkey)).First();
                string abc = machineconfigList.ToString();
                return abc;

            }
            catch (Exception)
            {

                return null;
            }
       
        }
        #endregion

    }
}
